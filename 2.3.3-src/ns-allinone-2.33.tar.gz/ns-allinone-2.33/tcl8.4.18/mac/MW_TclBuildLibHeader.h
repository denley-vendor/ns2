#if __POWERPC__
#include "MW_TclBuildLibHeaderPPC"
#elif __CFM68K__
#include "MW_TclBuildLibHeaderCFM68K"
#else
#include "MW_TclBuildLibHeader68K"
#endif
